from flask import Flask, render_template, request

from sklearn.preprocessing import StandardScaler

import pickle
app = Flask(__name__)

model = model = pickle.load(open('my1_classifier.pickle', 'rb'))
@app.route('/',methods=['GET'])
def Home():
    return render_template('index.html')


standard_to = StandardScaler()
@app.route("/predict", methods=['POST'])
def predict():
   
    if request.method == 'POST':
        Industrial_Risk = float(request.form['Industrial_Risk'])
        Management_Risk = float(request.form['Management_Risk'])
        Financial_Flexibility = float(request.form['Financial_Flexibility'])
        Credibility = float(request.form['Credibility'])
        Competitiveness = float(request.form['Competitiveness'])
        Operating_Risk = float(request.form['Operating_Risk'])
        prediction=model.predict([[Industrial_Risk,Management_Risk,Financial_Flexibility,Credibility,Competitiveness,Operating_Risk]])
        output=round(prediction[0],2)
        if output==0:
            return ("You are Bankrupted")
        elif output==1:
            return ("You are Not Bankrupted")
        else:
            return ("There is something error")
    else:
        return render_template('index.html')

if __name__=="__main__":
    app.run(debug=True)

